﻿using System;
using System.Diagnostics;
using System.IO;

namespace ExceptionSimples
{
    class Program
    {
        static void Main(string[] args)
        {

            #region Debug
            //Класс Debug предоставляет набор методов и свойств, помогающих при отладке кода.
            //Свойство Listeners получает коллекцию слушателей, отслеживающих данные отладки.
            Debug.Listeners.Add(new ConsoleTraceListener());
            Debug.Listeners.Add(new TextWriterTraceListener("text.txt"));
            Debug.Listeners.Add(new XmlWriterTraceListener("text.xml"));
            Debug.WriteLine("All bad!");
            Debug.Flush(); 
            #endregion

            ////Это событие предоставляет уведомление о неперехваченных исключениях. 
            ////Оно позволяет приложению записать в журнал информацию об исключении до того, 
            ////как системный обработчик по умолчанию сообщит пользователю об исключении и 
            ////прекратит выполнение приложения. Если имеется достаточно информации о состоянии 
            ////приложения, можно выполнить другие действия, такие как сохранение данных 
            ////программы для последующего восстановления. Рекомендуется действовать осторожно, 
            ////поскольку данные программы могут быть повреждены, если исключение не обработано.
            ////AppDomain.CurrentDomain.UnhandledException += UnhandledExceptionHandler;
            
            AppDomain.CurrentDomain.UnhandledException += UnhandledExceptionHandler;
            A();
            B();
            C();
        }

        private static void UnhandledExceptionHandler(object sender, UnhandledExceptionEventArgs unhandledExceptionEventArgs)
        {
            Debug.Listeners.Add(new TextWriterTraceListener("debuginfo.txt"));
            var ex = (Exception)unhandledExceptionEventArgs.ExceptionObject;
            Debug.WriteLine("Error \"{0}\" of type {1}", ex.Message, ex.GetType());
            Debug.WriteLine("Stack trace:");
            Debug.WriteLine(ex.StackTrace);
            Debug.Flush();
            Console.WriteLine("Error!");
        }

        static void A()
        {
            B();
        }

        static void B()
        {
            C();
        }

        static void C()
        {
            try
            {
                throw new FileNotFoundException();
            }
            catch (FileNotFoundException)
            {

            }
            throw new UnauthorizedAccessException();          
        }
    }
}
