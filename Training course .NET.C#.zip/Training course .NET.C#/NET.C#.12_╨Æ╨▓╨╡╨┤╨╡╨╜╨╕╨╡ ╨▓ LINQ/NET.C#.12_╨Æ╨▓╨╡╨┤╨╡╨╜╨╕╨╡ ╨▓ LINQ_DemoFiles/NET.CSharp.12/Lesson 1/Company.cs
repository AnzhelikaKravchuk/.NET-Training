﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lesson_1
{
    class Company
    {
        public string CompanyName { get; set; }
        public string Country { get; set; }
    }
}
